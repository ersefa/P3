package es.ucm.fdi.lps.p3.test.command;

import junit.framework.TestCase;

public class LookCommandTest extends TestCase {
	// Same as DropCommand
}
