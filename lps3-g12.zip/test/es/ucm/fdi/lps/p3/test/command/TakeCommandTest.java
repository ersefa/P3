package es.ucm.fdi.lps.p3.test.command;

import junit.framework.TestCase;

public class TakeCommandTest extends TestCase {
	// Same as DropCommand

}
